let nav = document.querySelector("#navbar-custom");

nav.innerHTML = `
<link href="https://fonts.googleapis.com/css2?family=Pathway+Extreme:wght@300&display=swap" rel="stylesheet">

<nav class="navbar navbar-expand-xl navbar-blue bg-light">
<a class="navbar-brand" href="/">
  <img src="./img/logo.png" width="150px" loading="lazy"/>
</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNav">
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a class="nav-link" href="/"style="font-weight: 500;font-size: 25px;">  Home&nbsp  <span class="sr-only">(current)</span></a>
    </li>
   
    <li class="nav-item">
      <a class="nav-link" href="./vote.html"style="font-weight: 500;font-size: 25px;">  Cast Vote  &nbsp</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="./blockvote-card.html"style="font-weight: 500;font-size: 25px;"> Vote Card &nbsp</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="./how-it-works.html"style="font-weight: 500;font-size: 25px;">  About &nbsp  &nbsp </a>
  </li>

  </ul>
</div>
</nav>`
